from flask import Flask, render_template
from IndexFunctions import CreateLinkObjects

app = Flask(__name__)

@app.route("/ReportingIndex")
def index():

    link_objects = CreateLinkObjects()
    link_data = link_objects.link_json()
    group_data = link_objects.group_json()

    return render_template("reporting_index.html", link_data=link_data, group_data=group_data)

if __name__ == "__main__":
    app.run(debug=True)