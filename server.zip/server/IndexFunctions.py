from models.classes import IndexLink, IndexGroup
import sqlite3
import json

class CreateLinkObjects:

    def __init__(self) -> None:

        self.connection = sqlite3.connect('./data/reporting_index.db')
        self.cursor = self.connection.cursor()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS index_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                image TEXT,
                amend_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS index_links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                name TEXT UNIQUE,
                description TEXT,
                url_uni TEXT,
                url_gau TEXT,
                url_kzn TEXT,
                url_swc TEXT,
                amend_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (group_id) REFERENCES index_groups(id)
            )
        ''')

        self.connection.commit()

    def add_link(self, group_id, name, description, url_uni, url_gau, url_kzn, url_swc):
        try:
            self.cursor.execute('''
                INSERT INTO index_links (group_id, name, description, url_uni, url_gau, url_kzn, url_swc)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (group_id, name, description, url_uni, url_gau, url_kzn, url_swc))
            self.connection.commit()
            return "Link successfully inserted."
        except sqlite3.IntegrityError:
            return "Insert failed: Link with the same name already exists."
        except Exception as e:
            return f"Insert failed: {str(e)}"

    def add_group(self, name, image):
        try:
            self.cursor.execute('''
                INSERT INTO index_groups (name, image)
                VALUES (?, ?)
            ''', (name, image))
            self.connection.commit()
            return "Group successfully inserted."
        except sqlite3.IntegrityError:
            return "Insert failed: Group with the same name already exists."
        except Exception as e:
            return f"Insert failed: {str(e)}"


    def update_link(self, link_id, group_id, name, description, url_uni, url_gau, url_kzn, url_swc):
        try:
            self.cursor.execute('''
                UPDATE index_links
                SET group_id=?, name=?, description=?, url_uni=?, url_gau=?, url_kzn=?, url_swc=?
                WHERE id=?
            ''', (group_id, name, description, url_uni, url_gau, url_kzn, url_swc, link_id))
            self.connection.commit()
            return "Link successfully updated."
        except sqlite3.IntegrityError:
            return "Update failed: Link with the same name already exists."
        except Exception as e:
            return f"Update failed: {str(e)}"

    def update_group(self, group_id, name, image):
        try:
            self.cursor.execute('''
                UPDATE index_groups
                SET name=?, image=?
                WHERE id=?
            ''', (name, image, group_id))
            self.connection.commit()
            return "Group successfully updated."
        except sqlite3.IntegrityError:
            return "Update failed: Group with the same name already exists."
        except Exception as e:
            return f"Update failed: {str(e)}"

    def delete_link(self, link_id):
        try:
            self.cursor.execute('''
                DELETE FROM index_links WHERE id=?
            ''', (link_id,))
            self.connection.commit()
            return "Link successfully deleted."
        except Exception as e:
            return f"Deletion failed: {str(e)}"

    def delete_group(self, group_id):
        try:
            self.cursor.execute('''
                DELETE FROM index_groups WHERE id=?
            ''', (group_id,))
            self.connection.commit()
            return "Group successfully deleted."
        except Exception as e:
            return f"Deletion failed: {str(e)}"


    def return_link_list(self):
        self.cursor.execute('''
            SELECT id, name, group_id, description, url_uni, url_gau, url_kzn, url_swc, amend_date
            FROM index_links
        ''')
        link_list = []
        for row in self.cursor.fetchall():
            id, name, group_id, description, url_uni, url_gau, url_kzn, url_swc, amend_date = row
            link = IndexLink(id, name, group_id, description, url_uni, url_gau, url_kzn, url_swc, amend_date)
            link_list.append(link)
        return link_list

    def return_group_list(self):
        self.cursor.execute('''
            SELECT id, name, image, amend_date
            FROM index_groups
        ''')
        group_list = []
        for row in self.cursor.fetchall():
            id, name, image, amend_date = row
            group = IndexGroup(id, name, image, amend_date)
            group_list.append(group)
        return group_list
    
    def link_json(self):
        link_list = self.return_link_list()
        json_string = json.dumps([obj.__dict__ for obj in link_list])
        return json_string

    def group_json(self):
        group_list = self.return_group_list()
        json_string = json.dumps([obj.__dict__ for obj in group_list])
        return json_string

    def close_connection(self):
        self.connection.close()

if __name__ == "__main__":
    link_objects = CreateLinkObjects()
    print(link_objects.group_json())
    print(link_objects.link_json())
    link_objects.close_connection()