class IndexLink:
    def __init__(self, id, name, group, description, url_uni, url_gau, url_kzn, url_swc, amend_date) -> None:
        self.id = id
        self.name = name
        self.group = group
        self.description = description
        self.url_uni = url_uni
        self.url_gau = url_gau
        self.url_kzn = url_kzn
        self.url_swc = url_swc
        self.amend_date = amend_date

class IndexGroup:
    def __init__(self, id, name, image, amend_date) -> None:
        self.id = id
        self.name = name
        self.image = image
        self.amend_date = amend_date


class AuthenticationObj:
    def __init__(self, user, admin) -> None:
        self.user = user
        self.admin = admin