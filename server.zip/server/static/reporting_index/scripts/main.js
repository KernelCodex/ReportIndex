let first_time_load = true;
let all_groups_list = [];

async function onPageLoad(group_data, link_data) {
    // Counter
    grouping_counter = {};
    for (let group_index = 0; group_index < group_data.length; group_index++) {
        for (let link_index = 0; link_index < link_data.length; link_index++) {
            if (group_data[group_index].id == link_data[link_index].group) {
                if (group_data[group_index].name in grouping_counter == false) {
                    grouping_counter[group_data[group_index].name] = 1;
                } else {
                    grouping_counter[group_data[group_index].name] += 1;
                }
            }
        }
    }

    // Initialize Code
    navigation_code = `
    <div class="navigation_card" onclick="NavClick('Home')">
        <div class="nav_image_container">
            <img src="/static/assets/pictures/home_logo_other.png" alt="Home">
        </div>
        <p class="navigation_card_title">Home</p>
    </div>
    `;
    index_code = ``;

    // Groups
    for (let group_index = 0; group_index < group_data.length; group_index++) {
        group = group_data[group_index];
        all_groups_list.push(group.name);

        // Group Card Code
        navigation_code += `
        <div class="navigation_card" onclick="NavClick('${group.name}')">
            <div class="nav_image_container">
                <img src="${group.image}" alt="${group.name}">
            </div>
            <p class="navigation_card_title">${group.name}</p>
        </div>
        `;

        // Start of Index Group
        index_code += `
        <div class="index_group_wrapper" id="${group.name}">
        <h2>${group.name}</h2>
        <div class="index_cards_wrapper">
        `;

        // Links in Group
        for (let link_index = 0; link_index < link_data.length; link_index++) {
            if (group.id == link_data[link_index].group) {
                link = link_data[link_index];

                // Index Card Code
                index_code += `
                <div class="index_card">
                    <div class="index_card_color"></div>
                    <div class="index_card_content">
                        <h4>${link.name}</h4></br>
                        <p>${link.description}</p>
                    </div>
                </div>
                `;
            }
        }

        for (let i = grouping_counter[group.name]; i < 4; i++) {
            index_code += `
            <div class="index_card index_invisible_card"></div>
            `;
        }

        // End of Index Group
        index_code += `</div></div>`;
    }

    // Write content to html document
    document.getElementById("navigation_body").innerHTML = navigation_code;
    document.getElementById("index_body").innerHTML = index_code;
}

// Show Nav Cards
function NavClick(group_to_show) {
    for (let i = 0; i < all_groups_list.length; i++) {
        if (all_groups_list[i] != group_to_show && group_to_show != "Home") {
            document.getElementById(all_groups_list[i]).style.display = "none";
        } else {
            document.getElementById(all_groups_list[i]).style.display = "block";
        }
    }
}
