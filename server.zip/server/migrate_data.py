def migrate_data(self):
    for group_name, group_data in self.read_data.items():
        self.cursor.execute('''
            INSERT OR IGNORE INTO index_groups (name, image)
            VALUES (?, ?)
        ''', (group_name, group_data[0]))

        self.cursor.execute('''
            SELECT id FROM index_groups WHERE name = ?
        ''', (group_name,))
        group_id = self.cursor.fetchone()[0]

        for link_data in group_data[1:]:
            self.cursor.execute('''
                INSERT OR IGNORE INTO index_links (group_id, name, description, url_uni, url_gau, url_kzn, url_swc)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (group_id, link_data['link_name'], link_data['link_description'], link_data['link_url_uni'], link_data['link_url_gau'], link_data['link_url_kzn'], link_data['link_url_swc']))

    self.connection.commit()